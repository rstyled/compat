pub fn f(a: i32) -> i32 {
    let mut x: i32 = a;
    x = 1;
    return x;
}

fn main() {
println!("{}", f(-100));
println!("{}", f(-1));
println!("{}", f(0));
println!("{}", f(1));
println!("{}", f(100));
}
