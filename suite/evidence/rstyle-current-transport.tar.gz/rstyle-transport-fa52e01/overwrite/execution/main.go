package main
import "fmt"

func F(a int32) int32 {
	x := a
	x = 1
	return x
}

func main() {
fmt.Println(F(-100))
fmt.Println(F(-1))
fmt.Println(F(0))
fmt.Println(F(1))
fmt.Println(F(100))
}
