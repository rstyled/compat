package main
import "fmt"

func F(a int32, b bool) int32 {
	x := a
	if b {
		x = 1
	} else {
		x = 2
	}
	return x
}

func main() {
fmt.Println(F(-100, false))
fmt.Println(F(-100, true))
fmt.Println(F(-1, false))
fmt.Println(F(-1, true))
fmt.Println(F(0, false))
fmt.Println(F(0, true))
fmt.Println(F(1, false))
fmt.Println(F(1, true))
fmt.Println(F(100, false))
fmt.Println(F(100, true))
}
