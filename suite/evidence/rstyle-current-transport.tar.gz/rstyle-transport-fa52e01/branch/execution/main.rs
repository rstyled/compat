pub fn f(a: i32, b: bool) -> i32 {
    let mut x: i32 = a;
    if b {
        x = 1;
    } else {
        x = 2;
    }
    return x;
}

fn main() {
println!("{}", f(-100, false));
println!("{}", f(-100, true));
println!("{}", f(-1, false));
println!("{}", f(-1, true));
println!("{}", f(0, false));
println!("{}", f(0, true));
println!("{}", f(1, false));
println!("{}", f(1, true));
println!("{}", f(100, false));
println!("{}", f(100, true));
}
