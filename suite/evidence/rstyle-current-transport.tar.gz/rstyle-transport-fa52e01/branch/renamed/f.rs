
// Formatting and binding-name metamorphism.
pub fn renamed(input_value: i32, decision: bool) -> i32 {

    let mut temporary: i32 = input_value;

    if decision {

        temporary = 1;

    } else {

        temporary = 2;

    }

    return temporary;

}

