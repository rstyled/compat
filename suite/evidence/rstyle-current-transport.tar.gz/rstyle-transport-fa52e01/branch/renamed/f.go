
// Formatting and binding-name metamorphism.
package fixture



func Renamed(input_value int32, decision bool) int32 {

    temporary := input_value

    if decision {

        temporary = 1

    } else {

        temporary = 2

    }

    return temporary

}

