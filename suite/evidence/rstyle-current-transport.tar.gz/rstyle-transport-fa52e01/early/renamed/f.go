
// Formatting and binding-name metamorphism.
package fixture



func Renamed(input_value int32, decision bool) int32 {

    if decision {

        return input_value

    }

    return 2

}

