
// Formatting and binding-name metamorphism.
pub fn renamed(input_value: i32, decision: bool) -> i32 {

    if decision {

        return input_value;

    }

    return 2;

}

