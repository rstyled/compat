pub fn f(a: i32, b: bool) -> i32 {
    if b {
        return a;
    }
    return 2;
}

fn main() {
println!("{}", f(-100, false));
println!("{}", f(-100, true));
println!("{}", f(-1, false));
println!("{}", f(-1, true));
println!("{}", f(0, false));
println!("{}", f(0, true));
println!("{}", f(1, false));
println!("{}", f(1, true));
println!("{}", f(100, false));
println!("{}", f(100, true));
}
