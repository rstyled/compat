pub fn f(a: i32) -> i32 {
    let x: i32 = -a;
    let y: i32 = -x;
    return y;
}

fn main() {
println!("{}", f(-100));
println!("{}", f(-1));
println!("{}", f(0));
println!("{}", f(1));
println!("{}", f(100));
}
