
// Formatting and binding-name metamorphism.
package fixture



func Renamed(input_value int32) int32 {

    temporary := -input_value

    next_value := -temporary

    return next_value

}

