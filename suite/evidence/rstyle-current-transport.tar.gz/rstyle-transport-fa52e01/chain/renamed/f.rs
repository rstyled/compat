
// Formatting and binding-name metamorphism.
pub fn renamed(input_value: i32) -> i32 {

    let temporary: i32 = -input_value;

    let next_value: i32 = -temporary;

    return next_value;

}

