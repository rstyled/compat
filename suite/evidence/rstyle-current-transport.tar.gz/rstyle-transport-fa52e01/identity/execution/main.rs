pub fn f(a: i32) -> i32 {
    return a;
}

fn main() {
println!("{}", f(-100));
println!("{}", f(-1));
println!("{}", f(0));
println!("{}", f(1));
println!("{}", f(100));
}
