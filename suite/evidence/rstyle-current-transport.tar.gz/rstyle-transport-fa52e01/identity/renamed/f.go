
// Formatting and binding-name metamorphism.
package fixture



func Renamed(input_value int32) int32 {

    return input_value

}

