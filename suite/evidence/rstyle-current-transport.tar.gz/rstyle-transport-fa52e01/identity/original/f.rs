pub fn f(a: i32) -> i32 {
    return a;
}
