
// Formatting and binding-name metamorphism.
package fixture



func Renamed(input_value bool, decision bool) bool {

    return input_value && decision

}

