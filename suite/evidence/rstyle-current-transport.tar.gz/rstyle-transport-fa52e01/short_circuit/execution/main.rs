pub fn f(a: bool, b: bool) -> bool {
    return a && b;
}

fn main() {
println!("{}", f(false, false));
println!("{}", f(false, true));
println!("{}", f(true, false));
println!("{}", f(true, true));
}
