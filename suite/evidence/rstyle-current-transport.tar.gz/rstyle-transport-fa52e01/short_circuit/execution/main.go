package main
import "fmt"

func F(a bool, b bool) bool {
	return a && b
}

func main() {
fmt.Println(F(false, false))
fmt.Println(F(false, true))
fmt.Println(F(true, false))
fmt.Println(F(true, true))
}
