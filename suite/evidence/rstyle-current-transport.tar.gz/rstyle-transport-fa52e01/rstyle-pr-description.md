Rstyle exports PDGs with record-level policies and an array of conformance assessments, which the current compat schema rejects. Add a borrowed typed transport used by paired exports, unit bundles and serialized PDG handoffs: one root profile, no record policies, and one conformance object. Reject conflicting internal policies or assessment inventories before projection; inherit the root profile on import for the existing strict verifier. Graph facts, evidence claims and namespaced proof records are preserved.

Driver and transport tests now validate against the current top-level schema. Historical snapshots remain unchanged. Existing profile-forgery tests mutate the current wire profile coherently so strict verification still rejects the wrong claim. Old exported wire documents require explicit migration.

Validation:

- 2,338 workspace nextest tests pass; five existing ignored tests skipped. Doctest commands pass with zero runnable doctests.
- Format, workspace/all-target Clippy with warnings denied, rstyle (zero violations) and patterns (zero active candidates) pass.
- Against unmerged gstyle PR #296 at `15f1681`: 24/24 independent graph expectations, 12/12 exact cross-language multigraph comparisons, 12/12 graph invariance checks, and all 39 shared-input executions pass.
- All 12 Rust exports now pass the shared schema. Compat comparator tests: 13 pass; existing shared schema/static tests: 35 pass.

Full compat still exits 1 for the pre-existing renamed Rust branch source-span failure and Go's incomplete extraction evidence. [Pinned results and raw evidence](https://github.com/rstyled/compat/blob/feat/tiny-pdg-compat-suite/suite/RSTYLE-TRANSPORT.md).
