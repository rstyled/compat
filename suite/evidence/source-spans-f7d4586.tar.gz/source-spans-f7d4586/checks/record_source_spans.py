from pathlib import Path
import copy
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
from datetime import datetime, timezone

repo = Path('/home/dev/src/rstyle-main/compat')
run = repo/'suite/artifacts/source-spans-f7d4586'
sys.path.insert(0, str(repo/'suite'))
from adapter import Incomplete
from source_correspondence import resolve_source, correspondence

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

summary = json.loads((run/'summary.json').read_text())
stats = dict(graph_passes=0, cross_passes=0, invariance_passes=0,
             schema_passes=0, source_content_passes=0, branch_correspondence_passes=0,
             runtime_pairs=0, shared_vectors=0, failures=[], incomplete_evidence=[],
             unsupported=[], not_run=[])
for case, result in summary.items():
    for variant in ('original', 'renamed'):
        stats['cross_passes'] += result[variant]['cross_language'] == 'pass'
        for language in ('go', 'rust'):
            record = result[variant][language]
            key = f'{case}/{variant}/{language}'
            for field, count in [('status','graph_passes'), ('schema','schema_passes')]:
                stats[count] += record[field] == 'pass'
                if record[field] != 'pass': stats['failures'].append([key,field,record[field]])
            for field, count in [('source_content','source_content_passes'),
                                 ('source_correspondence','branch_correspondence_passes')]:
                if field in record:
                    stats[count] += record[field]['status'] == 'pass'
                    if record[field]['status'] != 'pass': stats['failures'].append([key,field,record[field]])
            if record['evidence_status'] != 'pass': stats['incomplete_evidence'].append(key)
            for status in ('unsupported','not_run'):
                if record['status'] == status: stats[status].append(key)
    stats['invariance_passes'] += sum(v == 'pass' for v in result['invariance'].values())
    stats['runtime_pairs'] += result['execution']['status'] == 'pass'
    stats['shared_vectors'] += len(result['execution']['vectors'])
assert [stats[k] for k in ('graph_passes','cross_passes','invariance_passes','schema_passes',
                          'source_content_passes','branch_correspondence_passes',
                          'runtime_pairs','shared_vectors')] == [24,12,12,24,24,4,6,39]
assert not stats['failures'] and not stats['unsupported'] and not stats['not_run']
assert len(stats['incomplete_evidence']) == 12
assert all(key.endswith('/go') for key in stats['incomplete_evidence'])
save(run/'checked-results.json',stats)

directory = run/'branch/renamed'
doc = json.loads((directory/'rust.raw.json').read_text())
bundle = json.loads((directory/'rust/unit.evidence.json').read_text())
fixture = (directory/'f.rs').read_bytes()
anchors = json.loads((repo/'suite/cases/branch/correspondence.json').read_text())['anchors']
content, proof = resolve_source(doc,fixture,'rust',bundle)
mapping = correspondence(doc,content,anchors,True)
formal = next(n for n in doc['nodes'] if n['id'] == mapping['fa'])
assert formal['source_span']['start'] == 15 and formal['source_span']['end'] == 26
assert fixture.index(b'input_value') == 61 and proof['fixture_range'] == {'start':46,'end':260}
corruptions = []
for mutation in ('plus_one','minus_one','whole_file_offsets','unknown_source','wrong_digest'):
    changed = copy.deepcopy(doc)
    node = next(n for n in changed['nodes'] if n['id'] == mapping['fa'])
    if mutation in ('plus_one','minus_one','whole_file_offsets'):
        delta = {'plus_one':1,'minus_one':-1,'whole_file_offsets':46}[mutation]
        node['source_span']['start'] += delta
        node['source_span']['end'] += delta
    elif mutation == 'unknown_source': node['source_span']['source_id'] = 'unpublished-source'
    else: changed['sources'][0]['content_identity']['value'] = 'sha256:' + '0'*64
    try:
        corrupted_content, _ = resolve_source(changed,fixture,'rust',bundle)
        correspondence(changed,corrupted_content,anchors,True)
    except Incomplete as error:
        corruptions.append({'mutation':mutation,'status':'rejected_as_required',
                            'modified_formal_span':node['source_span'],'reason':str(error)})
    else: raise AssertionError('Corruption accepted: ' + mutation)
save(run/'source-corruption-checks.json',corruptions)

checks = run/'checks'
checks.mkdir()
shutil.copy2('/tmp/source-spans-compat-run.log',checks/'compat-run.log')
shutil.copy2('/tmp/source-correspondence-tests.log',checks/'suite-tests.log')
save(checks/'validation.json',{
    'compat_harness_exit':1,'only_full_conformance_blocker':'Go incomplete evidence',
    'suite_unit_tests':{'passed':17,'failed':0,'command':'uv run --no-project --with jsonschema python -m unittest discover -s suite -v',
                        'log_note':'suite-tests.log is the preceding successful run of the identical test code; verbose rerun also passed 17 tests'},
    'schema_unit_tests':{'passed':35,'failed':0,'command':'uv run --no-project --with jsonschema python -m unittest discover -s schemas -v',
                         'output_location':'Codex tool transcript; summary retained here'},
    'rust_workspace_tests':'not rerun: no producer changes; previous native-model archive retains 2332 passes',
    'remote_ci':'not run','other_platforms':'not run','non_branch_token_correspondence':'not asserted',
    'corruption_checks':'source-corruption-checks.json; independent synthetic UTF-8/BOM/CRLF checks in suite tests'})

refs = {'checked_utc':datetime.now(timezone.utc).isoformat()}
for name, path, heads in [
    ('rust','/home/dev/src/rstyle-compat-latest',['refs/heads/main','refs/heads/fix/current-pdg-transport']),
    ('go','/home/dev/src/gstyle-compat-latest',['refs/heads/master','refs/heads/fix/scalar-pdg-compatibility']),
    ('compat',str(repo),['refs/heads/main','refs/heads/feat/tiny-pdg-compat-suite'])]:
    refs[name] = subprocess.check_output(['git','ls-remote','origin',*heads],cwd=path,text=True)
save(run/'upstream-proof.json',refs)
shutil.copy2(__file__,checks/'record_source_spans.py')
print(json.dumps(stats,indent=2))
