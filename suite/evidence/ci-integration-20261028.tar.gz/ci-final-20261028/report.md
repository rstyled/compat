# Go/Rust compatibility: FAIL

118/130 checks pass; 12 nonpassing.

Incomplete evidence, unsupported extraction and checks not run all block this gate.

- gstyle: `1a47d25c7d62c18bbfa429ec3baafbf6cf6b7691`
- rstyle: `5b1b4e09ba4762ffe402338b65fa4fd472e652b6`

| Case | Variant | Producer | Check | Status | Reason | Details |
| --- | --- | --- | --- | --- | --- | --- |
| branch | original | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | branch/original/result.json |
| branch | renamed | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | branch/renamed/result.json |
| identity | original | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | identity/original/result.json |
| identity | renamed | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | identity/renamed/result.json |
| chain | original | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | chain/original/result.json |
| chain | renamed | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | chain/renamed/result.json |
| overwrite | original | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | overwrite/original/result.json |
| overwrite | renamed | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | overwrite/renamed/result.json |
| early | original | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | early/original/result.json |
| early | renamed | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | early/renamed/result.json |
| short_circuit | original | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | short_circuit/original/result.json |
| short_circuit | renamed | go | evidence | incomplete | node_extraction=approximated: Mixed statement/expression operations; closures are opaque; not a complete language lowering.; conformance=non_conformant: Dependency analysis and the shared extraction profile are incomplete. | short_circuit/renamed/result.json |

Download the run artifact for exact sources, raw outputs, configuration and mismatch details.
