Run the shared exact PDG compatibility suite on pull requests, pushes to master and manual dispatch. Test the triggering Go commit against Rust main, with manual ref overrides, using the workflow and harness pinned to compat 7366049.

Failures remain blocking, including incomplete evidence. The Action summary lists failing checks and retains raw graphs, exact inputs and logs. Required quality-baseline regeneration changes only its timestamp and revision.

Validation: actionlint passes; make check and make quality-gate pass. Local integration against current merged producer heads passes 118/130 checks; the 12 remaining failures are Go evidence limitations.
