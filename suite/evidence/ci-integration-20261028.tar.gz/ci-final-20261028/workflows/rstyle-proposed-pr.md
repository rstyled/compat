Run the shared exact PDG compatibility suite on pull requests, pushes to main and manual dispatch. Test the triggering Rust commit against Go master, with manual ref overrides, using the workflow and harness pinned to compat 7366049.

Failures remain blocking, including incomplete evidence. The Action summary lists failing checks and retains raw graphs, exact inputs and logs.

Validation: actionlint passes. Local integration against current merged producer heads passes 118/130 checks; the 12 remaining failures are Go evidence limitations. No Rust analyzer code changed.
