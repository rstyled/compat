# Go/Rust compatibility: FAIL

0/131 checks pass; 131 nonpassing.

Incomplete evidence, unsupported extraction and checks not run all block this gate.

| Case | Variant | Producer | Check | Status | Reason | Details |
| --- | --- | --- | --- | --- | --- | --- |
| branch | original | go | graph | not_run | See go.mismatch.json and producer command logs | branch/original/result.json |
| branch | original | go | schema | not_run | See go.schema-errors.json and producer command logs | branch/original/result.json |
| branch | original | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | branch/original/result.json |
| branch | original | go | source_content | not_run | Required source check did not run | branch/original/result.json |
| branch | original | go | source_correspondence | not_run | Required source check did not run | branch/original/result.json |
| branch | original | rust | graph | not_run | See rust.mismatch.json and producer command logs | branch/original/result.json |
| branch | original | rust | schema | not_run | See rust.schema-errors.json and producer command logs | branch/original/result.json |
| branch | original | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | branch/original/result.json |
| branch | original | rust | source_content | not_run | Required source check did not run | branch/original/result.json |
| branch | original | rust | source_correspondence | not_run | Required source check did not run | branch/original/result.json |
| branch | original | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | branch/original/result.json |
| branch | renamed | go | graph | not_run | See go.mismatch.json and producer command logs | branch/renamed/result.json |
| branch | renamed | go | schema | not_run | See go.schema-errors.json and producer command logs | branch/renamed/result.json |
| branch | renamed | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | branch/renamed/result.json |
| branch | renamed | go | source_content | not_run | Required source check did not run | branch/renamed/result.json |
| branch | renamed | go | source_correspondence | not_run | Required source check did not run | branch/renamed/result.json |
| branch | renamed | rust | graph | not_run | See rust.mismatch.json and producer command logs | branch/renamed/result.json |
| branch | renamed | rust | schema | not_run | See rust.schema-errors.json and producer command logs | branch/renamed/result.json |
| branch | renamed | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | branch/renamed/result.json |
| branch | renamed | rust | source_content | not_run | Required source check did not run | branch/renamed/result.json |
| branch | renamed | rust | source_correspondence | not_run | Required source check did not run | branch/renamed/result.json |
| branch | renamed | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | branch/renamed/result.json |
| branch | original+renamed | go | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| branch | original+renamed | rust | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| branch | original | go+rust | execution | not_run | See compilation exit codes, expected/actual outputs and command logs | branch/execution/result.json |
| identity | original | go | graph | not_run | See go.mismatch.json and producer command logs | identity/original/result.json |
| identity | original | go | schema | not_run | See go.schema-errors.json and producer command logs | identity/original/result.json |
| identity | original | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | identity/original/result.json |
| identity | original | go | source_content | not_run | Required source check did not run | identity/original/result.json |
| identity | original | rust | graph | not_run | See rust.mismatch.json and producer command logs | identity/original/result.json |
| identity | original | rust | schema | not_run | See rust.schema-errors.json and producer command logs | identity/original/result.json |
| identity | original | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | identity/original/result.json |
| identity | original | rust | source_content | not_run | Required source check did not run | identity/original/result.json |
| identity | original | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | identity/original/result.json |
| identity | renamed | go | graph | not_run | See go.mismatch.json and producer command logs | identity/renamed/result.json |
| identity | renamed | go | schema | not_run | See go.schema-errors.json and producer command logs | identity/renamed/result.json |
| identity | renamed | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | identity/renamed/result.json |
| identity | renamed | go | source_content | not_run | Required source check did not run | identity/renamed/result.json |
| identity | renamed | rust | graph | not_run | See rust.mismatch.json and producer command logs | identity/renamed/result.json |
| identity | renamed | rust | schema | not_run | See rust.schema-errors.json and producer command logs | identity/renamed/result.json |
| identity | renamed | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | identity/renamed/result.json |
| identity | renamed | rust | source_content | not_run | Required source check did not run | identity/renamed/result.json |
| identity | renamed | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | identity/renamed/result.json |
| identity | original+renamed | go | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| identity | original+renamed | rust | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| identity | original | go+rust | execution | not_run | See compilation exit codes, expected/actual outputs and command logs | identity/execution/result.json |
| chain | original | go | graph | not_run | See go.mismatch.json and producer command logs | chain/original/result.json |
| chain | original | go | schema | not_run | See go.schema-errors.json and producer command logs | chain/original/result.json |
| chain | original | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | chain/original/result.json |
| chain | original | go | source_content | not_run | Required source check did not run | chain/original/result.json |
| chain | original | rust | graph | not_run | See rust.mismatch.json and producer command logs | chain/original/result.json |
| chain | original | rust | schema | not_run | See rust.schema-errors.json and producer command logs | chain/original/result.json |
| chain | original | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | chain/original/result.json |
| chain | original | rust | source_content | not_run | Required source check did not run | chain/original/result.json |
| chain | original | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | chain/original/result.json |
| chain | renamed | go | graph | not_run | See go.mismatch.json and producer command logs | chain/renamed/result.json |
| chain | renamed | go | schema | not_run | See go.schema-errors.json and producer command logs | chain/renamed/result.json |
| chain | renamed | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | chain/renamed/result.json |
| chain | renamed | go | source_content | not_run | Required source check did not run | chain/renamed/result.json |
| chain | renamed | rust | graph | not_run | See rust.mismatch.json and producer command logs | chain/renamed/result.json |
| chain | renamed | rust | schema | not_run | See rust.schema-errors.json and producer command logs | chain/renamed/result.json |
| chain | renamed | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | chain/renamed/result.json |
| chain | renamed | rust | source_content | not_run | Required source check did not run | chain/renamed/result.json |
| chain | renamed | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | chain/renamed/result.json |
| chain | original+renamed | go | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| chain | original+renamed | rust | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| chain | original | go+rust | execution | not_run | See compilation exit codes, expected/actual outputs and command logs | chain/execution/result.json |
| overwrite | original | go | graph | not_run | See go.mismatch.json and producer command logs | overwrite/original/result.json |
| overwrite | original | go | schema | not_run | See go.schema-errors.json and producer command logs | overwrite/original/result.json |
| overwrite | original | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | overwrite/original/result.json |
| overwrite | original | go | source_content | not_run | Required source check did not run | overwrite/original/result.json |
| overwrite | original | rust | graph | not_run | See rust.mismatch.json and producer command logs | overwrite/original/result.json |
| overwrite | original | rust | schema | not_run | See rust.schema-errors.json and producer command logs | overwrite/original/result.json |
| overwrite | original | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | overwrite/original/result.json |
| overwrite | original | rust | source_content | not_run | Required source check did not run | overwrite/original/result.json |
| overwrite | original | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | overwrite/original/result.json |
| overwrite | renamed | go | graph | not_run | See go.mismatch.json and producer command logs | overwrite/renamed/result.json |
| overwrite | renamed | go | schema | not_run | See go.schema-errors.json and producer command logs | overwrite/renamed/result.json |
| overwrite | renamed | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | overwrite/renamed/result.json |
| overwrite | renamed | go | source_content | not_run | Required source check did not run | overwrite/renamed/result.json |
| overwrite | renamed | rust | graph | not_run | See rust.mismatch.json and producer command logs | overwrite/renamed/result.json |
| overwrite | renamed | rust | schema | not_run | See rust.schema-errors.json and producer command logs | overwrite/renamed/result.json |
| overwrite | renamed | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | overwrite/renamed/result.json |
| overwrite | renamed | rust | source_content | not_run | Required source check did not run | overwrite/renamed/result.json |
| overwrite | renamed | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | overwrite/renamed/result.json |
| overwrite | original+renamed | go | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| overwrite | original+renamed | rust | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| overwrite | original | go+rust | execution | not_run | See compilation exit codes, expected/actual outputs and command logs | overwrite/execution/result.json |
| early | original | go | graph | not_run | See go.mismatch.json and producer command logs | early/original/result.json |
| early | original | go | schema | not_run | See go.schema-errors.json and producer command logs | early/original/result.json |
| early | original | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | early/original/result.json |
| early | original | go | source_content | not_run | Required source check did not run | early/original/result.json |
| early | original | rust | graph | not_run | See rust.mismatch.json and producer command logs | early/original/result.json |
| early | original | rust | schema | not_run | See rust.schema-errors.json and producer command logs | early/original/result.json |
| early | original | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | early/original/result.json |
| early | original | rust | source_content | not_run | Required source check did not run | early/original/result.json |
| early | original | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | early/original/result.json |
| early | renamed | go | graph | not_run | See go.mismatch.json and producer command logs | early/renamed/result.json |
| early | renamed | go | schema | not_run | See go.schema-errors.json and producer command logs | early/renamed/result.json |
| early | renamed | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | early/renamed/result.json |
| early | renamed | go | source_content | not_run | Required source check did not run | early/renamed/result.json |
| early | renamed | rust | graph | not_run | See rust.mismatch.json and producer command logs | early/renamed/result.json |
| early | renamed | rust | schema | not_run | See rust.schema-errors.json and producer command logs | early/renamed/result.json |
| early | renamed | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | early/renamed/result.json |
| early | renamed | rust | source_content | not_run | Required source check did not run | early/renamed/result.json |
| early | renamed | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | early/renamed/result.json |
| early | original+renamed | go | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| early | original+renamed | rust | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| early | original | go+rust | execution | not_run | See compilation exit codes, expected/actual outputs and command logs | early/execution/result.json |
| short_circuit | original | go | graph | not_run | See go.mismatch.json and producer command logs | short_circuit/original/result.json |
| short_circuit | original | go | schema | not_run | See go.schema-errors.json and producer command logs | short_circuit/original/result.json |
| short_circuit | original | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | short_circuit/original/result.json |
| short_circuit | original | go | source_content | not_run | Required source check did not run | short_circuit/original/result.json |
| short_circuit | original | rust | graph | not_run | See rust.mismatch.json and producer command logs | short_circuit/original/result.json |
| short_circuit | original | rust | schema | not_run | See rust.schema-errors.json and producer command logs | short_circuit/original/result.json |
| short_circuit | original | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | short_circuit/original/result.json |
| short_circuit | original | rust | source_content | not_run | Required source check did not run | short_circuit/original/result.json |
| short_circuit | original | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | short_circuit/original/result.json |
| short_circuit | renamed | go | graph | not_run | See go.mismatch.json and producer command logs | short_circuit/renamed/result.json |
| short_circuit | renamed | go | schema | not_run | See go.schema-errors.json and producer command logs | short_circuit/renamed/result.json |
| short_circuit | renamed | go | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | short_circuit/renamed/result.json |
| short_circuit | renamed | go | source_content | not_run | Required source check did not run | short_circuit/renamed/result.json |
| short_circuit | renamed | rust | graph | not_run | See rust.mismatch.json and producer command logs | short_circuit/renamed/result.json |
| short_circuit | renamed | rust | schema | not_run | See rust.schema-errors.json and producer command logs | short_circuit/renamed/result.json |
| short_circuit | renamed | rust | evidence | not_run | node_extraction=missing: no evidence; parameters=missing: no evidence; returns=missing: no evidence; scalar_reaching_definitions=missing: no evidence; control_dependencies=missing: no evidence; execution_dependencies=missing: no evidence; conformance=missing | short_circuit/renamed/result.json |
| short_circuit | renamed | rust | source_content | not_run | Required source check did not run | short_circuit/renamed/result.json |
| short_circuit | renamed | go+rust | cross_language | not_run | See cross-language.mismatch.json and producer results | short_circuit/renamed/result.json |
| short_circuit | original+renamed | go | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| short_circuit | original+renamed | rust | invariance | not_run | Original and renamed graphs must be exactly equivalent; see their normalized graphs | summary.json |
| short_circuit | original | go+rust | execution | not_run | See compilation exit codes, expected/actual outputs and command logs | short_circuit/execution/result.json |
| setup |  |  | infrastructure | not_run | [Errno 2] No such file or directory: PosixPath('/tmp/compat-intentionally-missing-producer-20261028') | fatal.json |

Download the run artifact for exact sources, raw outputs, configuration and mismatch details.
