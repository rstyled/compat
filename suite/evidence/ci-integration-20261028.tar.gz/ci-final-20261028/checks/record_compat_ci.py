from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

repo=Path('/home/dev/src/rstyle-main/compat')
run=repo/'suite/artifacts/ci-final-20261028'
summary=json.loads((run/'summary.json').read_text())
outcome=json.loads((run/'outcome.json').read_text())
assert outcome == {'status':'fail','checks':130,'passed':118,'nonpassing':12,
                   'by_status':{'incomplete':12,'pass':118}}
failures=json.loads((run/'failures.json').read_text())['failures']
assert all(f['producer']=='go' and f['check']=='evidence' and f['status']=='incomplete' for f in failures)
assert all('node_extraction=approximated' in f['reason'] and 'conformance=non_conformant' in f['reason'] for f in failures)
assert not list(run.rglob('*junit*'))
assert len(summary)==6
assert sum(len(r['execution']['vectors']) for r in summary.values())==39
assert all(r['execution']['status']=='pass' for r in summary.values())
checks=run/'checks'
checks.mkdir()
for name,source in {
    'suite-tests.log':'/tmp/compat-ci-final-unit.log',
    'schema-tests.log':'/tmp/compat-ci-python312-schema.log',
    'actionlint.log':'/tmp/compat-ci-final-actionlint.log',
    'compat-run.log':'/tmp/compat-ci-final-run.log',
    'gstyle-check.log':'/tmp/gstyle-compat-ci-check.log',
    'gstyle-baseline.log':'/tmp/gstyle-compat-ci-baseline.log',
    'gstyle-quality-gate.log':'/tmp/gstyle-compat-ci-quality.log',
    'infrastructure-control.log':'/tmp/compat-ci-infrastructure-control.log',
    'github-status.json':'/tmp/compat-ci-github-status.json',
    'hosted-final-status.json':'/tmp/compat-ci-final-hosted-status.json',
}.items():
    shutil.copy2(source,checks/name)
assert 'Ran 20 tests' in (checks/'suite-tests.log').read_text()
assert 'Ran 35 tests' in (checks/'schema-tests.log').read_text()
assert not (checks/'actionlint.log').read_text().strip()
hosted=json.loads((checks/'hosted-final-status.json').read_text())
assert hosted['run']['status']=='completed' and hosted['run']['conclusion']=='failure'
steps={step['name']:step['conclusion'] for step in hosted['jobs']['jobs'][0]['steps']}
for name in ('Test comparator, adapter and reporting','Test shared schemas and independent fixtures',
             'Publish compatibility failure list','Retain raw outputs, failure list and exact inputs'):
    assert steps[name]=='success'
assert hosted['artifacts']['total_count']==1
assert any(a['message']=='Process completed with exit code 1.' for a in hosted['annotations'])
control=repo/'suite/artifacts/ci-infrastructure-control-20261028'
assert json.loads((control/'outcome.json').read_text())['by_status']=={'not_run':131}
shutil.copytree(control,checks/'infrastructure-control')
workflows=run/'workflows'
workflows.mkdir()
shutil.copy2(repo/'.github/workflows/compat.yml',workflows/'compat.yml')
for name,path,base in [
    ('gstyle',Path('/home/dev/src/gstyle-compat-ci'),'1a47d25c7d62c18bbfa429ec3baafbf6cf6b7691'),
    ('rstyle',Path('/home/dev/src/rstyle-compat-ci'),'5b1b4e09ba4762ffe402338b65fa4fd472e652b6')]:
    shutil.copy2(path/'.github/workflows/compat.yml',workflows/(name+'.yml'))
    shutil.copy2('/tmp/compat-ci-'+name+'-pr.md',workflows/(name+'-proposed-pr.md'))
    (workflows/(name+'.patch')).write_bytes(subprocess.check_output(['git','diff',base,'HEAD'],cwd=path))
    if name=='gstyle':
        before=json.loads(subprocess.check_output(['git','show',base+':quality-baseline.json'],cwd=path))
        after=json.loads((path/'quality-baseline.json').read_text())
        for field in ('generated_at','commit'):
            del before[field]
            del after[field]
        assert before==after
proof={}
for name,path,branch in [('gstyle','/home/dev/src/gstyle-compat-ci','master'),
                         ('rstyle','/home/dev/src/rstyle-compat-ci','main'),
                         ('compat',str(repo),'main')]:
    proof[name]=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],cwd=path,text=True).strip()
(run/'upstream-refs.json').write_text(json.dumps(proof,indent=2)+'\n')
shutil.copy2(repo/'suite/CI-RESULTS.md',run/'ci-validation-report.md')
shutil.copy2(__file__,checks/'record_compat_ci.py')
(checks/'validation.json').write_text(json.dumps({
    'suite_tests':{'passed':20,'failed':0},'schema_tests':{'passed':35,'failed':0},
    'actionlint':{'version':'1.7.12','workflows':3,'exit':0},
    'compat_harness_exit':1,'infrastructure_negative_control_exit':2,
    'gstyle_make_check_exit':0,'gstyle_quality_gate_exit':0,
    'gstyle_quality_baseline_metrics_unchanged':True,
    'hosted_execution':{'run_id':40643680312,'gate_exit':1,'summary_publication':'success','artifact_upload':'success',
                        'raw_log_download':'403 without account auth','artifact_download':'401 without account auth'},
    'rust_workspace_tests':'not rerun; workflow-only changes',
    'junit':'no output','expectations':'unchanged',
},indent=2)+'\n')
archive=repo/'suite/evidence/ci-integration-20261028.tar.gz'
with tarfile.open(archive,'x:gz') as output:
    for path in sorted(run.rglob('*')):
        if path.is_file() and path.name!='gstyle' and path.suffix not in ('.bin','.rmeta','.pyc'):
            output.add(path,arcname=Path(run.name)/path.relative_to(run),recursive=False)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
with (repo/'suite/evidence/SHA256SUMS').open('a') as output:
    output.write(f'{digest}  suite/evidence/{archive.name}\n')
print('archive',archive.name,'sha256',digest)
